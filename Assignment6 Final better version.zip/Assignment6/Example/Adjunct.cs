﻿
// Adjunct.cs
//
// Huimin Zhao
// 
// Adjunct class that extends Employee.
using System;

[Serializable]
public class Adjunct : Employee
{
  
    // parameter-less constructor
    public Adjunct() : base()
    {
    }

    // constructor
    public Adjunct(string first, string last, bool married, string gender, Address homeAddress, PhoneNumber homePhone, PhoneNumber cellPhone)
        : base(first, last, married, gender, homeAddress, homePhone, cellPhone)
    {
       
    } // end SalariedEmployee constructor



    

    // override Employee's abstract property EmployeeType 
    public override string EmployeeType
    {
        get
        {
            return "Adjunct";
        }
    } // end property Category


    
    // override Employee's abstract property RetirementPercentage 
    public override double RetirementPercentage
    {
        get
        {
            return 0;
        }
    } // end property RetirementPercentage

    // returns string representation of Employee object
    public override string ToString()
    {
        string result = Name + "\t"
        + EmployeeType + ", Salary: " + Salary.ToString("C")
        + ", Retirement: " + Retirement.ToString("C")
        + "(" + RetirementPercentage + "%), TSA: "
        + TSA.ToString("C") + ", Taxable Income: "
        + TaxableIncome.ToString("C")
        + ", TAX: " + TaxWithheld.ToString("C") + "(" + TaxWithholdingPercentage + "%), Health Insurance: "
        + HealthInsuranceAmount.ToString("C") + ", NetPay: "
        + NetPay.ToString("C") + ". " + HomeAddress + ". " + HomePhone + "/" + CellPhone + ". Contract till "+ContractDate.ToString("MM/dd/yyyy");


        return result;
    } // end method ToString


} // end class SalariedEmployee

