// Payroll.cs
//
// Huimin Zhao
// 
// Payroll System Main Form.

using System;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace Payroll
{
    public partial class PayrollSystemForm : Form
    {
        public PayrollSystemForm()
        {
            InitializeComponent();

            // populate the state combobox
            foreach (string state in Address.StateNames)
                cmbState.Items.Add(state);

            // clear all fields
            clear();
        }

        private void PayrollSystemForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to exit the system?",
                "Payroll System", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                e.Cancel = true;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void abroutPayrollSystemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Payroll Information System V1.0, by Huimin Zhao",
                "About Payroll System", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The printing function is still under construction!",
                "Payroll System", MessageBoxButtons.OK, MessageBoxIcon.Stop);
        }

        private void pageSetupStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The page setup function is still under construction!",
                "Payroll System", MessageBoxButtons.OK, MessageBoxIcon.Stop);
        }

        private void printPreviewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The print preview function is still under construction!",
                "Payroll System", MessageBoxButtons.OK, MessageBoxIcon.Stop);
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lstEmployees.Items.Count == 0)
                return;

            // object for serializing Records in binary format
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream output = null; // stream for writing to a file

            DialogResult result;
            string fileName; // name of file to save data

            // create dialog box enabling user to save file
            using (SaveFileDialog fileChooser = new SaveFileDialog())
            {
                fileChooser.CheckFileExists = false; // allow user to create file
                result = fileChooser.ShowDialog();
                fileName = fileChooser.FileName; // get specified file name
            }

            // exit event handler if user clicked "Cancel"
            if (result == DialogResult.Cancel)
                return;

            // show error if user specified invalid file
            if (fileName == "" || fileName == null)
            {
                MessageBox.Show("Invlaid File Name", "Error",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // save file via FileStream if user specified valid file
            try
            {
                // open file with write access
                output = new FileStream(fileName,
                   FileMode.OpenOrCreate, FileAccess.Write);
                // save records to file
                foreach (Employee item in lstEmployees.Items)
                {
                    formatter.Serialize(output, item);
                }
            } // end try
            // handle exception if there is a problem opening the file
            catch (IOException)
            {
                // notify user if file does not exist
                MessageBox.Show("Error opening file", "Error",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
            } // end catch
            // handle exception if there is a problem in serialization
            catch (SerializationException)
            {
                MessageBox.Show("Error writing to file", "Error",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
            } // end catch
            finally
            {
                if (output != null)
                    output.Close();
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // object for deserializing Record in binary format
            BinaryFormatter reader = new BinaryFormatter();
            FileStream input = null; // stream for reading from a file

            
            DialogResult result;
            string fileName; // name of file containing data

            // create dialog box enabling user to open file
            using (OpenFileDialog fileChooser = new OpenFileDialog())
            {
                result = fileChooser.ShowDialog();
                fileName = fileChooser.FileName; // get specified file name
            }


            // exit event handler if user clicked Cancel
            if (result == DialogResult.Cancel)
                return;

            // show error if user specified invalid file
            if (fileName == "" || fileName == null)
            {
                MessageBox.Show("Invalid File Name", "Error",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                // create FileStream to obtain read access to file
                input = new FileStream(
                   fileName, FileMode.Open, FileAccess.Read);

                // read records from file
                lstEmployees.Items.Clear();
                Employee employee = (Employee)reader.Deserialize(input);
                while (employee != null)
                {
                    lstEmployees.Items.Add(employee);
                    employee = (Employee)reader.Deserialize(input);
                }
            }
            catch
            {
            }
            finally
            {
                if (input != null)
                    input.Close();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            add();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // Make sure an item is selected in the list view.
            if (lstEmployees.SelectedItems.Count == 0)
            {
                return;
            }

            if (MessageBox.Show("Are you sure you want to update the following employee?\n" +
                (Employee)lstEmployees.SelectedItem,
               "Payroll System", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                return;

            if(add())
                lstEmployees.Items.Remove(lstEmployees.SelectedItem);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Make sure an item is selected in the list view.
            if (lstEmployees.SelectedItems.Count == 0)
            {
                return;
            }

            if (MessageBox.Show("Are you sure you want to delete the following employee?\n" +
                (Employee)lstEmployees.SelectedItem,
               "Payroll System", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                lstEmployees.Items.Remove(lstEmployees.SelectedItem);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void lstEmployees_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Make sure an item is selected in the list view.
            if (lstEmployees.SelectedItems.Count == 0)
            {
                return;
            }

            Employee employee = (Employee)lstEmployees.SelectedItem;
            clear();
            displayEmployee(employee);
        }

        // clear all fields
        private void clear()
        {
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtStreet.Text = "";
            txtCity.Text = "Milwaukee";
            cmbState.Text = "WISCONSIN";
            txtZip.Text = "53201";
            txtHomePhone.Text = "(414)";
            txtCellPhone.Text = "(414)"; 
            txtTaxWithholdingPercentage.Text = "";
            txtTaxWithheld.Text = "";
            txtSalary.Text = "";
            txtTSA.Text = "";
            txtAcademicDegree.Text = "";
            dateTimeContractEnding.Value = DateTime.Now;
            radAdjunct.Checked = true;
            radSingle.Checked = true;
            radStateInsurance.Checked = true;
            checkBoxTenured.Checked = false;
            txtEmployeeType.Text = "";
            txtRetirementPercentage.Text = "";
            txtRetirement.Text = "";
            txtHealthInsurance.Text = "";
            txtNetPay.Text = "";
            txtTaxableIncome.Text = "";

        }

        // add a new employee
        private bool add()
        {
            Employee employee;
            

            if (radAdjunct.Checked)
            {
                employee = new Adjunct();
            }
            else
            {
                employee = new Faculty();
                employee.Tenured = checkBoxTenured.Checked;
                employee.AcademicDegree = txtAcademicDegree.Text;
            }
            if (getInputs(employee) == true)
            {
                lstEmployees.Items.Add(employee);
                displayEmployee(employee);
                return true;
            }

            return false;
        }

        // get input fields of employee
        private bool getInputs(Employee employee)
        {
            try
            {
                employee.FirstName = txtFirstName.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,	Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtFirstName.Focus();
                return false;
            }

            try
            {
                employee.LastName = txtLastName.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtLastName.Focus();
                return false;
            }

            try
            {
                employee.HomePhone = new PhoneNumber(txtHomePhone.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtHomePhone.Focus();
                return false;
            }

            try
            {
                employee.CellPhone = new PhoneNumber(txtCellPhone.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCellPhone.Focus();
                return false;
            }

            try
            {
                employee.ContractDate = dateTimeContractEnding.Value;
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dateTimeContractEnding.Focus();
                return false;
            }
            


            if (radSingle.Checked)
                employee.MarriageStatus = radSingle.Text;
            else if (radMarriedNoChild.Checked)
                employee.MarriageStatus = radMarriedNoChild.Text;
            else if (radFamilyWithChildren.Checked)
                employee.MarriageStatus = radFamilyWithChildren.Text;

            if (radStateInsurance.Checked)
                employee.HealthInsurance = radStateInsurance.Text;
            else if (radHumanaInsurance.Checked)
                employee.HealthInsurance = radHumanaInsurance.Text;
            else if (radNoneInsurance.Checked)
                employee.HealthInsurance = radNoneInsurance.Text;

            try
            {
                employee.HomeAddress = new Address(txtStreet.Text, txtCity.Text, cmbState.Text, txtZip.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbState.Focus();
                return false;
            }


            try
            {
                if (txtSalary.Text == "")
                    txtSalary.Text = "0";
                employee.Salary = decimal.Parse(txtSalary.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSalary.Focus();
                return false;
            }

            try
            {
                if (txtTSA.Text == "")
                    txtTSA.Text = "0";
                employee.TSA = decimal.Parse(txtTSA.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTSA.Focus();
                return false;
            }


            return true;
        }

        // display employee
        private void displayEmployee(Employee employee)
        {
            txtFirstName.Text = employee.FirstName;
            txtLastName.Text = employee.LastName;
            txtHomePhone.Text = employee.HomePhone.ToString();
            txtCellPhone.Text = employee.CellPhone.ToString();
             txtStreet.Text = employee.HomeAddress.Street;
            txtCity.Text = employee.HomeAddress.City;
            cmbState.Text = employee.HomeAddress.State;
            txtZip.Text = employee.HomeAddress.Zip;
            txtNetPay.Text = employee.NetPay.ToString("C");
            txtTaxWithholdingPercentage.Text = employee.TaxWithholdingPercentage.ToString();
            txtTaxWithheld.Text = employee.TaxWithheld.ToString("C");
            txtEmployeeType.Text = employee.EmployeeType;
            txtRetirementPercentage.Text = employee.RetirementPercentage.ToString();
            txtRetirement.Text = employee.Retirement.ToString("C");
            txtTSA.Text = employee.TSA.ToString();
            txtTaxableIncome.Text = employee.TaxableIncome.ToString("C");
            txtHealthInsurance.Text = employee.HealthInsuranceAmount.ToString("C");
            txtNetPay.Text = employee.NetPay.ToString("C");

          
        }

        private void PayrollSystemForm_Load(object sender, EventArgs e)
        {

        }

    }
}