﻿

// Faculty.cs
//
// Huimin Zhao
// 
// Faculty class that extends Employee.
using System;

[Serializable]
public class Faculty : Employee
{
    // private instance variable for storing weekly salary
    private decimal SalaryValue;

    // parameter-less constructor
    public Faculty() : base()
    {
    }

    // constructor
    public Faculty(string first, string last, bool married, string gender, Address homeAddress, PhoneNumber homePhone, PhoneNumber cellPhone, decimal weeklySalary)
        : base(first, last, married, gender, homeAddress, homePhone, cellPhone)
    {
        this.Salary = Salary;
    } // end SalariedEmployee constructor

    

    // override Employee's abstract property EmployeeType 
    public override string EmployeeType
    {
        get
        {
            return "Faculty";
        }
    } // end property Category


  

    // override Employee's abstract property RetirementPercentage 
    public override double RetirementPercentage
    {
        get
        {
            return 4.5;
        }
    } // end property RetirementPercentage

    // returns string representation of Employee object
    public override string ToString()
    {
        string result = Name + "\t"
        + EmployeeType + ", Salary: " + Salary.ToString("C")
        + ", Retirement: " + Retirement.ToString("C")
        + "(" + RetirementPercentage + "%), TSA: "
        + TSA.ToString("C") + ", Taxable Income: "
        + TaxableIncome.ToString("C")
        + ", TAX: " + TaxWithheld.ToString("C") + "(" + TaxWithholdingPercentage + "%), Health Insurance: "
        + HealthInsuranceAmount.ToString("C") + ", NetPay: "
        + NetPay.ToString("C") + ". " + HomeAddress + ". " + HomePhone + "/" + CellPhone +". "
        +AcademicDegree;

        if(Tenured)
        {
            result += ", Tenured";
        }
        return result;
    } // end method ToString


} // end class SalariedEmployee

