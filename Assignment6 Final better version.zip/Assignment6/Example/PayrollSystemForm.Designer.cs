namespace Payroll
{
    partial class PayrollSystemForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.pageSetupStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abroutPayrollSystemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labWageRate = new System.Windows.Forms.Label();
            this.labWeeklySalary = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtZip = new System.Windows.Forms.TextBox();
            this.cmbState = new System.Windows.Forms.ComboBox();
            this.txtCellPhone = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtHomePhone = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtTaxWithholdingPercentage = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTaxWithheld = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.lstEmployees = new System.Windows.Forms.ListBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radFaculty = new System.Windows.Forms.RadioButton();
            this.radAdjunct = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radFamilyWithChildren = new System.Windows.Forms.RadioButton();
            this.radMarriedNoChild = new System.Windows.Forms.RadioButton();
            this.radSingle = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.radNoneInsurance = new System.Windows.Forms.RadioButton();
            this.radHumanaInsurance = new System.Windows.Forms.RadioButton();
            this.radStateInsurance = new System.Windows.Forms.RadioButton();
            this.label14 = new System.Windows.Forms.Label();
            this.dateTimeContractEnding = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.txtAcademicDegree = new System.Windows.Forms.TextBox();
            this.checkBoxTenured = new System.Windows.Forms.CheckBox();
            this.txtSalary = new System.Windows.Forms.TextBox();
            this.txtTSA = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtEmployeeType = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtRetirementPercentage = new System.Windows.Forms.TextBox();
            this.txtRetirement = new System.Windows.Forms.TextBox();
            this.txtHealthInsurance = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtNetPay = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTaxableIncome = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1106, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.toolStripSeparator3,
            this.saveToolStripMenuItem,
            this.toolStripSeparator2,
            this.pageSetupStripMenuItem,
            this.printToolStripMenuItem,
            this.printPreviewToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.openToolStripMenuItem.Text = "&Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(174, 6);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.saveToolStripMenuItem.Text = "&Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(174, 6);
            // 
            // pageSetupStripMenuItem
            // 
            this.pageSetupStripMenuItem.Name = "pageSetupStripMenuItem";
            this.pageSetupStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.pageSetupStripMenuItem.Text = "Page Setup";
            this.pageSetupStripMenuItem.Click += new System.EventHandler(this.pageSetupStripMenuItem_Click);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printToolStripMenuItem.Text = "Print";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printPreviewToolStripMenuItem.Text = "Print Preview";
            this.printPreviewToolStripMenuItem.Click += new System.EventHandler(this.printPreviewToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(174, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.abroutPayrollSystemToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(55, 24);
            this.editToolStripMenuItem.Text = "Help";
            // 
            // abroutPayrollSystemToolStripMenuItem
            // 
            this.abroutPayrollSystemToolStripMenuItem.Name = "abroutPayrollSystemToolStripMenuItem";
            this.abroutPayrollSystemToolStripMenuItem.Size = new System.Drawing.Size(237, 26);
            this.abroutPayrollSystemToolStripMenuItem.Text = "&Abrout Payroll System";
            this.abroutPayrollSystemToolStripMenuItem.Click += new System.EventHandler(this.abroutPayrollSystemToolStripMenuItem_Click);
            // 
            // labWageRate
            // 
            this.labWageRate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labWageRate.Location = new System.Drawing.Point(722, 276);
            this.labWageRate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labWageRate.Name = "labWageRate";
            this.labWageRate.Size = new System.Drawing.Size(153, 26);
            this.labWageRate.TabIndex = 113;
            this.labWageRate.Text = "HealthInsurance:";
            this.labWageRate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labWeeklySalary
            // 
            this.labWeeklySalary.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labWeeklySalary.Location = new System.Drawing.Point(736, 103);
            this.labWeeklySalary.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labWeeklySalary.Name = "labWeeklySalary";
            this.labWeeklySalary.Size = new System.Drawing.Size(131, 26);
            this.labWeeklySalary.TabIndex = 112;
            this.labWeeklySalary.Text = "Retirement (%): ";
            this.labWeeklySalary.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(497, 487);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(80, 28);
            this.btnDelete.TabIndex = 15;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Location = new System.Drawing.Point(265, 487);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(80, 28);
            this.btnUpdate.TabIndex = 14;
            this.btnUpdate.Text = "&Update";
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // txtLastName
            // 
            this.txtLastName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLastName.Location = new System.Drawing.Point(461, 51);
            this.txtLastName.Margin = new System.Windows.Forms.Padding(4);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(145, 26);
            this.txtLastName.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(356, 54);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 19);
            this.label1.TabIndex = 100;
            this.label1.Text = "Last Name:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(49, 54);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 19);
            this.label3.TabIndex = 99;
            this.label3.Text = "First Name:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFirstName.Location = new System.Drawing.Point(156, 51);
            this.txtFirstName.Margin = new System.Windows.Forms.Padding(4);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(145, 26);
            this.txtFirstName.TabIndex = 0;
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(52, 487);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(80, 28);
            this.btnAdd.TabIndex = 13;
            this.btnAdd.Text = "&Add";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(695, 487);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(80, 28);
            this.btnClear.TabIndex = 16;
            this.btnClear.Text = "&Clear";
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtStreet
            // 
            this.txtStreet.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStreet.Location = new System.Drawing.Point(156, 244);
            this.txtStreet.Margin = new System.Windows.Forms.Padding(4);
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.Size = new System.Drawing.Size(452, 26);
            this.txtStreet.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(49, 247);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 19);
            this.label2.TabIndex = 118;
            this.label2.Text = "Address:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtCity
            // 
            this.txtCity.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCity.Location = new System.Drawing.Point(156, 271);
            this.txtCity.Margin = new System.Windows.Forms.Padding(4);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(189, 26);
            this.txtCity.TabIndex = 5;
            // 
            // txtZip
            // 
            this.txtZip.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtZip.Location = new System.Drawing.Point(511, 272);
            this.txtZip.Margin = new System.Windows.Forms.Padding(4);
            this.txtZip.Name = "txtZip";
            this.txtZip.Size = new System.Drawing.Size(97, 26);
            this.txtZip.TabIndex = 7;
            // 
            // cmbState
            // 
            this.cmbState.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbState.FormattingEnabled = true;
            this.cmbState.Location = new System.Drawing.Point(358, 271);
            this.cmbState.Margin = new System.Windows.Forms.Padding(4);
            this.cmbState.Name = "cmbState";
            this.cmbState.Size = new System.Drawing.Size(145, 27);
            this.cmbState.TabIndex = 6;
            // 
            // txtCellPhone
            // 
            this.txtCellPhone.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCellPhone.Location = new System.Drawing.Point(432, 314);
            this.txtCellPhone.Margin = new System.Windows.Forms.Padding(4);
            this.txtCellPhone.Name = "txtCellPhone";
            this.txtCellPhone.Size = new System.Drawing.Size(145, 26);
            this.txtCellPhone.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(331, 317);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 19);
            this.label4.TabIndex = 124;
            this.label4.Text = "Cell Phone:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(34, 321);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 19);
            this.label6.TabIndex = 123;
            this.label6.Text = "Home Phone:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtHomePhone
            // 
            this.txtHomePhone.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHomePhone.Location = new System.Drawing.Point(156, 314);
            this.txtHomePhone.Margin = new System.Windows.Forms.Padding(4);
            this.txtHomePhone.Name = "txtHomePhone";
            this.txtHomePhone.Size = new System.Drawing.Size(145, 26);
            this.txtHomePhone.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(722, 70);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(145, 26);
            this.label7.TabIndex = 125;
            this.label7.Text = "Employee Type:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTaxWithholdingPercentage
            // 
            this.txtTaxWithholdingPercentage.BackColor = System.Drawing.SystemColors.Control;
            this.txtTaxWithholdingPercentage.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTaxWithholdingPercentage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTaxWithholdingPercentage.Location = new System.Drawing.Point(890, 206);
            this.txtTaxWithholdingPercentage.Margin = new System.Windows.Forms.Padding(4);
            this.txtTaxWithholdingPercentage.Name = "txtTaxWithholdingPercentage";
            this.txtTaxWithholdingPercentage.ReadOnly = true;
            this.txtTaxWithholdingPercentage.Size = new System.Drawing.Size(145, 26);
            this.txtTaxWithholdingPercentage.TabIndex = 130;
            this.txtTaxWithholdingPercentage.TabStop = false;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(788, 205);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 26);
            this.label9.TabIndex = 129;
            this.label9.Text = "Tax (%):   ";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTaxWithheld
            // 
            this.txtTaxWithheld.BackColor = System.Drawing.SystemColors.Control;
            this.txtTaxWithheld.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTaxWithheld.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTaxWithheld.Location = new System.Drawing.Point(890, 240);
            this.txtTaxWithheld.Margin = new System.Windows.Forms.Padding(4);
            this.txtTaxWithheld.Name = "txtTaxWithheld";
            this.txtTaxWithheld.ReadOnly = true;
            this.txtTaxWithheld.Size = new System.Drawing.Size(145, 26);
            this.txtTaxWithheld.TabIndex = 132;
            this.txtTaxWithheld.TabStop = false;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(788, 240);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(94, 26);
            this.label12.TabIndex = 131;
            this.label12.Text = "Tax ($):  ";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lstEmployees
            // 
            this.lstEmployees.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstEmployees.FormattingEnabled = true;
            this.lstEmployees.HorizontalScrollbar = true;
            this.lstEmployees.ItemHeight = 19;
            this.lstEmployees.Location = new System.Drawing.Point(43, 547);
            this.lstEmployees.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lstEmployees.Name = "lstEmployees";
            this.lstEmployees.Size = new System.Drawing.Size(846, 99);
            this.lstEmployees.TabIndex = 19;
            this.lstEmployees.SelectedIndexChanged += new System.EventHandler(this.lstEmployees_SelectedIndexChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radFaculty);
            this.groupBox3.Controls.Add(this.radAdjunct);
            this.groupBox3.Location = new System.Drawing.Point(43, 368);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(117, 84);
            this.groupBox3.TabIndex = 137;
            this.groupBox3.TabStop = false;
            // 
            // radFaculty
            // 
            this.radFaculty.AutoSize = true;
            this.radFaculty.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radFaculty.Location = new System.Drawing.Point(9, 50);
            this.radFaculty.Margin = new System.Windows.Forms.Padding(4);
            this.radFaculty.Name = "radFaculty";
            this.radFaculty.Size = new System.Drawing.Size(83, 23);
            this.radFaculty.TabIndex = 1;
            this.radFaculty.Text = "Faculty";
            this.radFaculty.UseVisualStyleBackColor = true;
            // 
            // radAdjunct
            // 
            this.radAdjunct.AutoSize = true;
            this.radAdjunct.Checked = true;
            this.radAdjunct.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radAdjunct.Location = new System.Drawing.Point(9, 18);
            this.radAdjunct.Margin = new System.Windows.Forms.Padding(4);
            this.radAdjunct.Name = "radAdjunct";
            this.radAdjunct.Size = new System.Drawing.Size(84, 23);
            this.radAdjunct.TabIndex = 0;
            this.radAdjunct.TabStop = true;
            this.radAdjunct.Text = "Adjunct";
            this.radAdjunct.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.radAdjunct.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radFamilyWithChildren);
            this.groupBox4.Controls.Add(this.radMarriedNoChild);
            this.groupBox4.Controls.Add(this.radSingle);
            this.groupBox4.Location = new System.Drawing.Point(154, 119);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(210, 100);
            this.groupBox4.TabIndex = 138;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Status";
            // 
            // radFamilyWithChildren
            // 
            this.radFamilyWithChildren.AutoSize = true;
            this.radFamilyWithChildren.Font = new System.Drawing.Font("Arial", 8F);
            this.radFamilyWithChildren.Location = new System.Drawing.Point(8, 73);
            this.radFamilyWithChildren.Margin = new System.Windows.Forms.Padding(4);
            this.radFamilyWithChildren.Name = "radFamilyWithChildren";
            this.radFamilyWithChildren.Size = new System.Drawing.Size(159, 20);
            this.radFamilyWithChildren.TabIndex = 2;
            this.radFamilyWithChildren.Text = "Family With Children";
            this.radFamilyWithChildren.UseVisualStyleBackColor = true;
            // 
            // radMarriedNoChild
            // 
            this.radMarriedNoChild.AutoSize = true;
            this.radMarriedNoChild.Font = new System.Drawing.Font("Arial", 8F);
            this.radMarriedNoChild.Location = new System.Drawing.Point(8, 45);
            this.radMarriedNoChild.Margin = new System.Windows.Forms.Padding(4);
            this.radMarriedNoChild.Name = "radMarriedNoChild";
            this.radMarriedNoChild.Size = new System.Drawing.Size(138, 20);
            this.radMarriedNoChild.TabIndex = 1;
            this.radMarriedNoChild.Text = "Married, No Child";
            this.radMarriedNoChild.UseVisualStyleBackColor = true;
            // 
            // radSingle
            // 
            this.radSingle.AutoSize = true;
            this.radSingle.Checked = true;
            this.radSingle.Font = new System.Drawing.Font("Arial", 8F);
            this.radSingle.Location = new System.Drawing.Point(8, 17);
            this.radSingle.Margin = new System.Windows.Forms.Padding(4);
            this.radSingle.Name = "radSingle";
            this.radSingle.Size = new System.Drawing.Size(68, 20);
            this.radSingle.TabIndex = 0;
            this.radSingle.TabStop = true;
            this.radSingle.Text = "Single";
            this.radSingle.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.radSingle.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.radNoneInsurance);
            this.groupBox5.Controls.Add(this.radHumanaInsurance);
            this.groupBox5.Controls.Add(this.radStateInsurance);
            this.groupBox5.Location = new System.Drawing.Point(445, 119);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(210, 100);
            this.groupBox5.TabIndex = 139;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Health Insurance";
            // 
            // radNoneInsurance
            // 
            this.radNoneInsurance.AutoSize = true;
            this.radNoneInsurance.Font = new System.Drawing.Font("Arial", 8F);
            this.radNoneInsurance.Location = new System.Drawing.Point(8, 73);
            this.radNoneInsurance.Margin = new System.Windows.Forms.Padding(4);
            this.radNoneInsurance.Name = "radNoneInsurance";
            this.radNoneInsurance.Size = new System.Drawing.Size(62, 20);
            this.radNoneInsurance.TabIndex = 2;
            this.radNoneInsurance.Text = "None";
            this.radNoneInsurance.UseVisualStyleBackColor = true;
            // 
            // radHumanaInsurance
            // 
            this.radHumanaInsurance.AutoSize = true;
            this.radHumanaInsurance.Font = new System.Drawing.Font("Arial", 8F);
            this.radHumanaInsurance.Location = new System.Drawing.Point(8, 45);
            this.radHumanaInsurance.Margin = new System.Windows.Forms.Padding(4);
            this.radHumanaInsurance.Name = "radHumanaInsurance";
            this.radHumanaInsurance.Size = new System.Drawing.Size(81, 20);
            this.radHumanaInsurance.TabIndex = 1;
            this.radHumanaInsurance.Text = "Humana";
            this.radHumanaInsurance.UseVisualStyleBackColor = true;
            // 
            // radStateInsurance
            // 
            this.radStateInsurance.AutoSize = true;
            this.radStateInsurance.Checked = true;
            this.radStateInsurance.Font = new System.Drawing.Font("Arial", 8F);
            this.radStateInsurance.Location = new System.Drawing.Point(8, 17);
            this.radStateInsurance.Margin = new System.Windows.Forms.Padding(4);
            this.radStateInsurance.Name = "radStateInsurance";
            this.radStateInsurance.Size = new System.Drawing.Size(62, 20);
            this.radStateInsurance.TabIndex = 0;
            this.radStateInsurance.TabStop = true;
            this.radStateInsurance.Text = "State";
            this.radStateInsurance.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.radStateInsurance.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(203, 377);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(132, 19);
            this.label14.TabIndex = 140;
            this.label14.Text = "Contract Ending:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dateTimeContractEnding
            // 
            this.dateTimeContractEnding.CustomFormat = "mm/dd/yy";
            this.dateTimeContractEnding.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeContractEnding.Location = new System.Drawing.Point(358, 374);
            this.dateTimeContractEnding.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeContractEnding.Name = "dateTimeContractEnding";
            this.dateTimeContractEnding.Size = new System.Drawing.Size(145, 22);
            this.dateTimeContractEnding.TabIndex = 141;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(203, 410);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(146, 19);
            this.label15.TabIndex = 142;
            this.label15.Text = "Academic Degree:";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtAcademicDegree
            // 
            this.txtAcademicDegree.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAcademicDegree.Location = new System.Drawing.Point(357, 407);
            this.txtAcademicDegree.Margin = new System.Windows.Forms.Padding(4);
            this.txtAcademicDegree.Name = "txtAcademicDegree";
            this.txtAcademicDegree.Size = new System.Drawing.Size(145, 26);
            this.txtAcademicDegree.TabIndex = 143;
            // 
            // checkBoxTenured
            // 
            this.checkBoxTenured.AutoSize = true;
            this.checkBoxTenured.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBoxTenured.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxTenured.Location = new System.Drawing.Point(529, 406);
            this.checkBoxTenured.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxTenured.Name = "checkBoxTenured";
            this.checkBoxTenured.Size = new System.Drawing.Size(89, 23);
            this.checkBoxTenured.TabIndex = 144;
            this.checkBoxTenured.Text = "Tenured";
            this.checkBoxTenured.UseVisualStyleBackColor = true;
            // 
            // txtSalary
            // 
            this.txtSalary.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalary.Location = new System.Drawing.Point(156, 85);
            this.txtSalary.Margin = new System.Windows.Forms.Padding(4);
            this.txtSalary.Name = "txtSalary";
            this.txtSalary.Size = new System.Drawing.Size(91, 26);
            this.txtSalary.TabIndex = 145;
            // 
            // txtTSA
            // 
            this.txtTSA.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTSA.Location = new System.Drawing.Point(461, 85);
            this.txtTSA.Margin = new System.Windows.Forms.Padding(4);
            this.txtTSA.Name = "txtTSA";
            this.txtTSA.Size = new System.Drawing.Size(91, 26);
            this.txtTSA.TabIndex = 146;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(49, 88);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(61, 19);
            this.label16.TabIndex = 147;
            this.label16.Text = "Salary:";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(402, 88);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(45, 19);
            this.label17.TabIndex = 148;
            this.label17.Text = "TSA:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtEmployeeType
            // 
            this.txtEmployeeType.BackColor = System.Drawing.SystemColors.Control;
            this.txtEmployeeType.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmployeeType.Location = new System.Drawing.Point(890, 70);
            this.txtEmployeeType.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmployeeType.Name = "txtEmployeeType";
            this.txtEmployeeType.ReadOnly = true;
            this.txtEmployeeType.Size = new System.Drawing.Size(145, 26);
            this.txtEmployeeType.TabIndex = 149;
            this.txtEmployeeType.TabStop = false;
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(751, 138);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(131, 26);
            this.label18.TabIndex = 150;
            this.label18.Text = "Retirement :  ";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtRetirementPercentage
            // 
            this.txtRetirementPercentage.BackColor = System.Drawing.SystemColors.Control;
            this.txtRetirementPercentage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRetirementPercentage.Location = new System.Drawing.Point(890, 104);
            this.txtRetirementPercentage.Margin = new System.Windows.Forms.Padding(4);
            this.txtRetirementPercentage.Name = "txtRetirementPercentage";
            this.txtRetirementPercentage.ReadOnly = true;
            this.txtRetirementPercentage.Size = new System.Drawing.Size(145, 26);
            this.txtRetirementPercentage.TabIndex = 151;
            this.txtRetirementPercentage.TabStop = false;
            // 
            // txtRetirement
            // 
            this.txtRetirement.BackColor = System.Drawing.SystemColors.Control;
            this.txtRetirement.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRetirement.Location = new System.Drawing.Point(890, 138);
            this.txtRetirement.Margin = new System.Windows.Forms.Padding(4);
            this.txtRetirement.Name = "txtRetirement";
            this.txtRetirement.ReadOnly = true;
            this.txtRetirement.Size = new System.Drawing.Size(145, 26);
            this.txtRetirement.TabIndex = 152;
            this.txtRetirement.TabStop = false;
            // 
            // txtHealthInsurance
            // 
            this.txtHealthInsurance.BackColor = System.Drawing.SystemColors.Control;
            this.txtHealthInsurance.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtHealthInsurance.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHealthInsurance.Location = new System.Drawing.Point(890, 276);
            this.txtHealthInsurance.Margin = new System.Windows.Forms.Padding(4);
            this.txtHealthInsurance.Name = "txtHealthInsurance";
            this.txtHealthInsurance.ReadOnly = true;
            this.txtHealthInsurance.Size = new System.Drawing.Size(145, 26);
            this.txtHealthInsurance.TabIndex = 153;
            this.txtHealthInsurance.TabStop = false;
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(751, 310);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(153, 26);
            this.label13.TabIndex = 154;
            this.label13.Text = "Net Pay:";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtNetPay
            // 
            this.txtNetPay.BackColor = System.Drawing.SystemColors.Control;
            this.txtNetPay.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNetPay.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNetPay.Location = new System.Drawing.Point(890, 310);
            this.txtNetPay.Margin = new System.Windows.Forms.Padding(4);
            this.txtNetPay.Name = "txtNetPay";
            this.txtNetPay.ReadOnly = true;
            this.txtNetPay.Size = new System.Drawing.Size(145, 26);
            this.txtNetPay.TabIndex = 155;
            this.txtNetPay.TabStop = false;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(721, 171);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(161, 26);
            this.label5.TabIndex = 156;
            this.label5.Text = "Taxable Income: ";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTaxableIncome
            // 
            this.txtTaxableIncome.BackColor = System.Drawing.SystemColors.Control;
            this.txtTaxableIncome.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTaxableIncome.Location = new System.Drawing.Point(890, 172);
            this.txtTaxableIncome.Margin = new System.Windows.Forms.Padding(4);
            this.txtTaxableIncome.Name = "txtTaxableIncome";
            this.txtTaxableIncome.ReadOnly = true;
            this.txtTaxableIncome.Size = new System.Drawing.Size(145, 26);
            this.txtTaxableIncome.TabIndex = 157;
            this.txtTaxableIncome.TabStop = false;
            // 
            // PayrollSystemForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1106, 657);
            this.Controls.Add(this.txtTaxableIncome);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtNetPay);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtHealthInsurance);
            this.Controls.Add(this.txtRetirement);
            this.Controls.Add(this.txtRetirementPercentage);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txtEmployeeType);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtTSA);
            this.Controls.Add(this.txtSalary);
            this.Controls.Add(this.checkBoxTenured);
            this.Controls.Add(this.txtAcademicDegree);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.dateTimeContractEnding);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.lstEmployees);
            this.Controls.Add(this.txtTaxWithheld);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtTaxWithholdingPercentage);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtCellPhone);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtHomePhone);
            this.Controls.Add(this.cmbState);
            this.Controls.Add(this.txtZip);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtStreet);
            this.Controls.Add(this.labWageRate);
            this.Controls.Add(this.labWeeklySalary);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "PayrollSystemForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Min\'s IT - Payroll System";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PayrollSystemForm_FormClosing);
            this.Load += new System.EventHandler(this.PayrollSystemForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem pageSetupStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abroutPayrollSystemToolStripMenuItem;
        private System.Windows.Forms.Label labWageRate;
        private System.Windows.Forms.Label labWeeklySalary;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox txtStreet;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtZip;
        private System.Windows.Forms.ComboBox cmbState;
        private System.Windows.Forms.TextBox txtCellPhone;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtHomePhone;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtTaxWithholdingPercentage;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtTaxWithheld;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListBox lstEmployees;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radFaculty;
        private System.Windows.Forms.RadioButton radAdjunct;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton radMarriedNoChild;
        private System.Windows.Forms.RadioButton radSingle;
        private System.Windows.Forms.RadioButton radFamilyWithChildren;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton radNoneInsurance;
        private System.Windows.Forms.RadioButton radHumanaInsurance;
        private System.Windows.Forms.RadioButton radStateInsurance;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dateTimeContractEnding;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtAcademicDegree;
        private System.Windows.Forms.CheckBox checkBoxTenured;
        private System.Windows.Forms.TextBox txtSalary;
        private System.Windows.Forms.TextBox txtTSA;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtEmployeeType;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtRetirementPercentage;
        private System.Windows.Forms.TextBox txtRetirement;
        private System.Windows.Forms.TextBox txtHealthInsurance;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtNetPay;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtTaxableIncome;
    }
}

